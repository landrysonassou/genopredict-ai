# 🧬 GenoPredict-AI

**Plateforme Intelligente de Diagnostic Prédictif et de Modélisation Thérapeutique des Maladies Génétiques**

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.10%2B-blue.svg)
![Tests](https://img.shields.io/badge/tests-72%20passed-brightgreen.svg)
![Status](https://img.shields.io/badge/status-recherche%20%2F%20démonstration-orange.svg)

> ⚠️ **Avertissement** — GenoPredict-AI est un projet de recherche et de
> démonstration technique open-source. Ce n'est **ni un dispositif
> médical, ni un outil de diagnostic clinique**. Toutes les données
> fournies par défaut sont **entièrement simulées**. Aucune décision de
> santé ne doit être prise sur la base de ses résultats — voir la
> [section Avertissement clinique](#-avertissement-clinique).

---

## 📖 Sommaire

- [Problématique](#-problématique)
- [Architecture](#-architecture)
- [Installation](#-installation)
- [Démarrage rapide](#-démarrage-rapide)
- [Pipeline détaillé](#-pipeline-détaillé)
- [Tableau de bord interactif](#-tableau-de-bord-interactif)
- [Tests](#-tests)
- [Formats de données](#-formats-de-données)
- [Avertissement clinique](#-avertissement-clinique)
- [Licence](#-licence)

---

## 🎯 Problématique

Les maladies génétiques et à composante polygénique (cardiovasculaires,
oncologiques, métaboliques...) résultent de l'interaction complexe entre
de nombreux variants génétiques à faible effet individuel et des
facteurs cliniques/environnementaux. L'identification précoce des
profils à risque, couplée à une orientation thérapeutique préventive
personnalisée, est un enjeu central de la médecine génomique moderne —
en particulier dans les contextes de recherche où l'accès aux outils
d'analyse reste limité.

**GenoPredict-AI** propose un pipeline bio-informatique de bout en bout,
reproductible et testé, qui :

1. **Ingère** des matrices de variants génétiques (format VCF simplifié) et
   applique un contrôle qualité (QC) génotypique rigoureux.
2. **Construit des caractéristiques** exploitables par le Machine
   Learning, incluant un score de risque polygénique (PRS) simplifié,
   sans fuite de données entre les ensembles d'entraînement et de test.
3. **Entraîne** des modèles de classification (XGBoost / Random Forest)
   avec validation croisée stratifiée et métriques cliniques standard.
4. **Interprète** les prédictions via les valeurs SHAP, pour une
   traçabilité compatible avec un usage en recherche translationnelle.
5. **Génère des recommandations préventives et pharmacogénomiques**
   simplifiées, croisant le profil de risque avec une base de
   connaissances gène-médicament inspirée des catégories publiques du CPIC.
6. **Expose le tout via un tableau de bord Streamlit** interactif.

---

## 🏗 Architecture

```
genopredict_ai/
│
├── data/
│   └── generate_synthetic_data.py   # Génère un jeu de données simulé (aucune donnée réelle)
├── notebooks/
│   └── 01_exploratory_data_analysis.ipynb   # EDA et validation statistique
├── src/
│   ├── __init__.py
│   ├── ingestion.py       # Parsing, décodage génotypique, contrôle qualité (QC)
│   ├── features.py        # Feature engineering, PRS, pipeline sans fuite de données
│   ├── models.py          # Entraînement XGBoost/Random Forest, CV, métriques, SHAP
│   ├── treatment.py       # Recommandations préventives et pharmacogénomiques
│   └── api_dashboard.py   # Tableau de bord interactif Streamlit
├── tests/                 # Suite de tests unitaires pytest (72 tests)
├── requirements.txt
├── README.md
├── LICENSE
└── .gitignore
```

Chaque module est documenté avec des *docstrings* au format Google Style
et des annotations de type (*type hints*), et couvert par des tests
unitaires dédiés.

---

## ⚙️ Installation

```bash
git clone https://github.com/<votre-utilisateur>/genopredict-ai.git
cd genopredict-ai

python3 -m venv .venv
source .venv/bin/activate        # Windows : .venv\Scripts\activate

pip install -r requirements.txt
```

Prérequis : **Python 3.10+**.

---

## 🚀 Démarrage rapide

### 1. Générer le jeu de données de démonstration (100% simulé)

```bash
python data/generate_synthetic_data.py --n-samples 600 --n-variants 40 --output-dir data/
```

Cela produit `data/variant_matrix.csv` (génotypes + variables cliniques +
statut de la maladie) et `data/annotations.csv` (gène, conséquence,
score CADD, MAF, taille d'effet par variant).

### 2. Exécuter le pipeline complet en Python

```python
from src import ingestion, features, models, treatment
from sklearn.model_selection import train_test_split

# 1. Ingestion + QC
df = ingestion.load_variant_matrix("data/variant_matrix.csv")
annotations = ingestion.load_annotations("data/annotations.csv")
clinical_cols = ["sex", "age", "bmi", "smoking_status"]
variant_cols = ingestion.identify_variant_columns(df, clinical_cols)
clean_df, qc_report = ingestion.quality_control(df, variant_cols)
print(qc_report.summary())

kept_variants = [c for c in variant_cols if c not in qc_report.dropped_variants]

# 2. Split train/test (AVANT tout fit de transformation, pour éviter les fuites)
y = clean_df["disease_status"]
train_idx, test_idx = train_test_split(
    list(clean_df.index), test_size=0.2, stratify=y.to_numpy(), random_state=42
)

# 3. Feature engineering (fit sur train uniquement)
prs = features.compute_polygenic_risk_score(clean_df[kept_variants], annotations["effect_size"])
spec = features.FeatureSpec(
    numeric_clinical_columns=["age", "bmi"],
    categorical_clinical_columns=["sex", "smoking_status"],
    variant_columns=kept_variants,
)
builder = features.FeatureBuilder(spec)
X_train = builder.fit_transform(clean_df.loc[train_idx], prs=prs.loc[train_idx])
X_test = builder.transform(clean_df.loc[test_idx], prs=prs.loc[test_idx])
y_train, y_test = y.loc[train_idx], y.loc[test_idx]

# 4. Entraînement + validation croisée stratifiée
model, cv_report = models.train_model(X_train, y_train, model_type="xgboost", n_splits=5)
print(cv_report.summary())

# 5. Prédiction + interprétabilité SHAP
risk_df = models.predict_risk(model, X_test)
explanation = models.compute_shap_values(model, X_test)
print(models.top_shap_features(explanation, sample_index=0, top_k=5))

# 6. Recommandations préventives / pharmacogénomiques
sample_id = X_test.index[0]
profile = treatment.recommend_care(
    sample_id=sample_id,
    risk_probability=float(risk_df.loc[sample_id, "probability"]),
    carried_genes=["BRCA1", "CYP2D6"],
)
print(profile.to_dict())
```

### 3. Lancer le tableau de bord interactif

```bash
streamlit run src/api_dashboard.py
```

---

## 🔬 Pipeline détaillé

| Étape | Module | Description |
|---|---|---|
| Ingestion | `src/ingestion.py` | Chargement et validation stricte des fichiers CSV, décodage des génotypes VCF simplifiés (`0/0`, `0/1`, `1/1`, `./.`) en dosages additifs, contrôle qualité (taux d'appel, MAF, complétude par échantillon). |
| Feature Engineering | `src/features.py` | Encodage numérique sans fuite de données via `sklearn.compose.ColumnTransformer` (imputation + normalisation + one-hot encoding, *fit* sur train uniquement), calcul du score de risque polygénique (PRS). |
| Modélisation | `src/models.py` | Entraînement XGBoost ou Random Forest, validation croisée stratifiée (`StratifiedKFold`), métriques cliniques (sensibilité, spécificité, ROC-AUC, matrice de confusion, F1), interprétabilité par valeurs SHAP (`shap.TreeExplainer`). |
| Thérapeutique | `src/treatment.py` | Catégorisation du risque clinique, recommandations préventives, alertes pharmacogénomiques basées sur une base de connaissances gène-médicament simplifiée. |
| Interface | `src/api_dashboard.py` | Tableau de bord Streamlit : chargement de données, entraînement en un clic, jauge de risque, graphique SHAP interactif (Plotly), recommandations cliniques. |

---

## 🖥 Tableau de bord interactif

Le tableau de bord permet de :
- Charger vos propres fichiers CSV (matrice de variants + annotations) ou utiliser le jeu de données simulé par défaut.
- Choisir le type de modèle (XGBoost / Random Forest) et les seuils de QC.
- Sélectionner un échantillon de test et visualiser sa probabilité de risque (jauge), les caractéristiques les plus influentes (graphique SHAP) et les recommandations cliniques associées.

```bash
streamlit run src/api_dashboard.py
```

---

## ✅ Tests

La suite de tests couvre l'ingestion, le feature engineering, la
modélisation et le moteur de recommandation (72 tests, validés avant
livraison) :

```bash
pytest tests/ -v
```

---

## 📁 Formats de données

**Matrice de variants** (`variant_matrix.csv`) :

| sample_id | sex | age | bmi | smoking_status | rs1234567 | ... | disease_status |
|---|---|---|---|---|---|---|---|
| SAMPLE_0001 | F | 42.0 | 24.1 | never | 0/1 | ... | 0 |

**Annotations de variants** (`annotations.csv`) :

| variant_id | gene | consequence | cadd_score | effect_allele_freq | effect_size |
|---|---|---|---|---|---|
| rs1234567 | APOE | missense_variant | 18.4 | 0.12 | 0.31 |

---

## ⚕️ Avertissement clinique

Ce projet est fourni à des fins **éducatives, de recherche et de
démonstration technique**. Il :

- N'a fait l'objet d'aucune validation clinique ni d'aucune certification réglementaire (ex. dispositif médical).
- Utilise, par défaut, des données **entièrement synthétiques** générées par simulation statistique (`data/generate_synthetic_data.py`), sans lien avec des individus réels.
- Ne doit **jamais** être utilisé pour poser un diagnostic, orienter une décision thérapeutique ou remplacer l'avis d'un professionnel de santé qualifié.

Toute utilisation avec des données génomiques réelles doit se conformer
aux réglementations applicables (ex. RGPD, consentement éclairé, comités
d'éthique de la recherche).

---

## 📜 Licence

Ce projet est distribué sous licence [MIT](LICENSE).
